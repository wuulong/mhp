
  # AI 詐騙辨識系統原型設計

  This is a code bundle for AI 詐騙辨識系統原型設計. The original project is available at https://www.figma.com/design/FRoxGYHsqHoTgs3y1tqSd3/AI-%E8%A9%90%E9%A8%99%E8%BE%A8%E8%AD%98%E7%B3%BB%E7%B5%B1%E5%8E%9F%E5%9E%8B%E8%A8%AD%E8%A8%88.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  