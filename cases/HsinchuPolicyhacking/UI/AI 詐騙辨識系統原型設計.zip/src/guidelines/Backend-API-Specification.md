# AI 詐騙辨識與預警系統 - 後端 API 規格文件

## 目錄
1. [API 概述](#api-概述)
2. [認證與安全](#認證與安全)
3. [通用規範](#通用規範)
4. [核心 API 端點](#核心-api-端點)
5. [數據模型](#數據模型)
6. [錯誤代碼](#錯誤代碼)
7. [性能要求](#性能要求)
8. [部署建議](#部署建議)

---

## API 概述

### 基礎資訊
- **API 版本**: v1
- **Base URL**: `https://api.hsinchu-scam-detector.tw/v1`
- **協議**: HTTPS only
- **格式**: JSON
- **編碼**: UTF-8

### 環境端點
```
開發環境: https://dev-api.hsinchu-scam-detector.tw/v1
測試環境: https://staging-api.hsinchu-scam-detector.tw/v1
生產環境: https://api.hsinchu-scam-detector.tw/v1
```

---

## 認證與安全

### 認證方式

#### 1. API Key（推薦用於前端）
```http
Authorization: Bearer YOUR_API_KEY
```

#### 2. JWT Token（用於用戶認證）
```http
Authorization: Bearer JWT_TOKEN
```

### 安全要求
- 所有請求必須使用 HTTPS
- API Key 應存儲在環境變數
- 實施 Rate Limiting (詳見各端點)
- 支援 CORS，限制允許的來源

### Rate Limiting
```
一般用戶: 100 requests/hour
註冊用戶: 500 requests/hour
管理員: 無限制
```

**Rate Limit Headers**:
```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1699123456
```

---

## 通用規範

### HTTP 方法
- `GET`: 獲取資源
- `POST`: 創建資源
- `PUT`: 完整更新資源
- `PATCH`: 部分更新資源
- `DELETE`: 刪除資源

### 標準請求 Headers
```http
Content-Type: application/json
Accept: application/json
Authorization: Bearer {token}
X-Client-Version: 1.0.0
```

### 標準響應格式

#### 成功響應
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "timestamp": "2024-11-04T10:30:00Z",
    "version": "1.0.0"
  }
}
```

#### 錯誤響應
```json
{
  "success": false,
  "error": {
    "code": "INVALID_INPUT",
    "message": "輸入內容不能為空",
    "details": {
      "field": "text",
      "reason": "Required field is missing"
    }
  },
  "meta": {
    "timestamp": "2024-11-04T10:30:00Z",
    "version": "1.0.0"
  }
}
```

### 分頁格式
```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "total": 150,
    "totalPages": 8,
    "hasNext": true,
    "hasPrev": false
  }
}
```

---

## 核心 API 端點

## 1. 詐騙分析 API

### 1.1 分析文字內容

**端點**: `POST /analyze`

**描述**: 分析輸入的文字內容，返回詐騙風險評估

**Rate Limit**: 50 requests/hour

**請求格式**:
```http
POST /v1/analyze
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY
```

**Request Body**:
```json
{
  "text": "您好，這裡是台北地檢署，您的帳戶涉及洗錢案件...",
  "metadata": {
    "source": "sms",           // 可選: sms, phone, email, other
    "userAgent": "Mozilla/5.0...",
    "timestamp": "2024-11-04T10:30:00Z"
  },
  "options": {
    "detailed": true,           // 是否返回詳細分析
    "includeRecommendations": true
  }
}
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "analysisId": "ana_1234567890abcdef",
    "riskLevel": "high",
    "riskScore": 85,
    "confidence": 0.92,
    "reasons": [
      {
        "type": "keyword",
        "severity": "high",
        "description": "包含高風險關鍵字：「地檢署」",
        "weight": 30
      },
      {
        "type": "keyword",
        "severity": "high",
        "description": "包含高風險關鍵字：「洗錢」",
        "weight": 30
      },
      {
        "type": "pattern",
        "severity": "medium",
        "description": "使用緊急或限時詞彙，製造壓力",
        "weight": 15
      },
      {
        "type": "contact",
        "severity": "medium",
        "description": "要求撥打未經證實的電話號碼",
        "weight": 10
      }
    ],
    "recommendation": {
      "text": "此訊息具有高度詐騙風險！請勿點擊任何連結、撥打電話或提供個人資料。建議立即向 165 反詐騙專線查證。",
      "actions": [
        {
          "type": "call",
          "label": "撥打 165 反詐騙專線",
          "value": "tel:165",
          "priority": 1
        },
        {
          "type": "link",
          "label": "前往刑事局網站查證",
          "value": "https://www.165.gov.tw/",
          "priority": 2
        }
      ]
    },
    "detectedPatterns": {
      "impersonation": ["government_agency"],
      "urgency": ["immediate_action"],
      "threats": ["account_freeze"],
      "requestedInfo": ["phone_call"]
    },
    "similarCases": [
      {
        "caseId": "case_987654321",
        "similarity": 0.88,
        "reportedDate": "2024-10-15",
        "status": "confirmed_scam"
      }
    ]
  },
  "meta": {
    "timestamp": "2024-11-04T10:30:00Z",
    "version": "1.0.0",
    "processingTime": 342
  }
}
```

**錯誤響應**:

400 Bad Request - 輸入無效:
```json
{
  "success": false,
  "error": {
    "code": "INVALID_INPUT",
    "message": "輸入內容不能為空",
    "details": {
      "field": "text",
      "constraint": "minLength: 10"
    }
  }
}
```

429 Too Many Requests - 超過頻率限制:
```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "已超過請求頻率限制",
    "details": {
      "limit": 50,
      "resetAt": "2024-11-04T11:00:00Z"
    }
  }
}
```

---

### 1.2 批次分析

**端點**: `POST /analyze/batch`

**描述**: 批次分析多條訊息（管理員功能）

**Rate Limit**: 10 requests/hour, 最多 100 條訊息/請求

**Request Body**:
```json
{
  "items": [
    {
      "id": "msg_001",
      "text": "恭喜您中獎了..."
    },
    {
      "id": "msg_002",
      "text": "這裡是地檢署..."
    }
  ]
}
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "batchId": "batch_abc123",
    "results": [
      {
        "id": "msg_001",
        "analysisId": "ana_xyz789",
        "riskLevel": "high",
        "riskScore": 75
      },
      {
        "id": "msg_002",
        "analysisId": "ana_xyz790",
        "riskLevel": "high",
        "riskScore": 90
      }
    ],
    "summary": {
      "total": 2,
      "high": 2,
      "medium": 0,
      "safe": 0
    }
  }
}
```

---

## 2. 用戶回饋 API

### 2.1 提交回饋

**端點**: `POST /feedback`

**描述**: 用戶對分析結果提供準確度回饋

**Rate Limit**: 100 requests/hour

**Request Body**:
```json
{
  "analysisId": "ana_1234567890abcdef",
  "isAccurate": true,
  "feedbackType": "accurate",  // accurate, inaccurate, false_positive, false_negative
  "comment": "分析很準確",        // 可選
  "additionalInfo": {
    "actualOutcome": "confirmed_scam",  // 可選
    "reportedToPolice": true            // 可選
  },
  "userInfo": {
    "sessionId": "session_xyz123",
    "userAgent": "Mozilla/5.0..."
  }
}
```

**成功響應** (201 Created):
```json
{
  "success": true,
  "data": {
    "feedbackId": "fb_abcdef123456",
    "analysisId": "ana_1234567890abcdef",
    "status": "received",
    "message": "感謝您的回饋！您的意見將幫助我們改進 AI 辨識系統。",
    "points": 10  // 未來可用於積分系統
  },
  "meta": {
    "timestamp": "2024-11-04T10:30:00Z"
  }
}
```

---

### 2.2 獲取回饋統計

**端點**: `GET /feedback/stats`

**描述**: 獲取系統回饋統計數據（管理員）

**Query Parameters**:
```
?startDate=2024-10-01
&endDate=2024-11-04
&groupBy=day
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "period": {
      "start": "2024-10-01",
      "end": "2024-11-04"
    },
    "totalFeedbacks": 1250,
    "accuracy": {
      "accurate": 1050,
      "inaccurate": 200,
      "accuracyRate": 0.84
    },
    "byRiskLevel": {
      "high": {
        "total": 500,
        "accurate": 450,
        "accuracyRate": 0.90
      },
      "medium": {
        "total": 400,
        "accurate": 320,
        "accuracyRate": 0.80
      },
      "safe": {
        "total": 350,
        "accurate": 280,
        "accuracyRate": 0.80
      }
    },
    "trends": [
      {
        "date": "2024-11-01",
        "total": 320,
        "accuracyRate": 0.85
      },
      {
        "date": "2024-11-02",
        "total": 310,
        "accuracyRate": 0.83
      }
    ]
  }
}
```

---

## 3. 詐騙案例庫 API

### 3.1 獲取範例案例

**端點**: `GET /examples`

**描述**: 獲取常見詐騙訊息範例

**Query Parameters**:
```
?category=government_impersonation  // 可選: government_impersonation, lottery, investment
&limit=10
&language=zh-TW
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "examples": [
      {
        "id": "ex_001",
        "category": "government_impersonation",
        "title": "假冒公務機關",
        "text": "您好，這裡是台北地檢署，您的帳戶涉及洗錢案件，請立即撥打 02-1234-5678 配合調查，否則將凍結您的所有帳戶。",
        "riskLevel": "high",
        "tags": ["地檢署", "洗錢", "凍結帳戶"],
        "educationalNotes": "政府機關不會透過電話要求提供帳戶資訊或匯款"
      },
      {
        "id": "ex_002",
        "category": "lottery",
        "title": "假中獎通知",
        "text": "恭喜您！您已被選中獲得 iPhone 15 Pro Max 一台，請點擊此連結 https://bit.ly/xxxxx 填寫資料領取，限時 24 小時。",
        "riskLevel": "high",
        "tags": ["中獎", "限時", "可疑連結"],
        "educationalNotes": "正規抽獎不會要求先提供個人資料或付費"
      },
      {
        "id": "ex_003",
        "category": "investment",
        "title": "投資詐騙",
        "text": "獨家投資機會！加入 LINE 群組 @investpro，每月穩定獲利 30%，已有 5000 人加入，名額有限！立即私訊了解詳情。",
        "riskLevel": "high",
        "tags": ["投資", "高獲利", "LINE群組"],
        "educationalNotes": "保證高額獲利的投資機會通常是詐騙"
      }
    ],
    "categories": [
      {
        "id": "government_impersonation",
        "name": "假冒公務機關",
        "count": 150
      },
      {
        "id": "lottery",
        "name": "假中獎通知",
        "count": 120
      },
      {
        "id": "investment",
        "name": "投資詐騙",
        "count": 100
      }
    ]
  }
}
```

---

### 3.2 搜尋相似案例

**端點**: `POST /cases/search`

**描述**: 根據輸入文字搜尋相似的已知詐騙案例

**Request Body**:
```json
{
  "text": "您的帳戶異常，請立即處理",
  "limit": 5,
  "minSimilarity": 0.7
}
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "matches": [
      {
        "caseId": "case_12345",
        "similarity": 0.89,
        "text": "您的帳戶發生異常，請盡快聯繫客服...",
        "category": "phishing",
        "reportedDate": "2024-10-20",
        "verificationStatus": "confirmed_scam",
        "victimCount": 23
      },
      {
        "caseId": "case_12346",
        "similarity": 0.76,
        "text": "系統檢測到您的帳號異常登入...",
        "category": "phishing",
        "reportedDate": "2024-10-18",
        "verificationStatus": "confirmed_scam",
        "victimCount": 15
      }
    ],
    "totalMatches": 2
  }
}
```

---

## 4. 統計與報表 API

### 4.1 系統統計總覽

**端點**: `GET /stats/overview`

**描述**: 獲取系統使用統計（公開）

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "totalAnalyses": 125000,
    "last24Hours": 3200,
    "last7Days": 18500,
    "riskDistribution": {
      "high": 45000,
      "medium": 35000,
      "safe": 45000
    },
    "topScamTypes": [
      {
        "type": "government_impersonation",
        "name": "假冒公務機關",
        "count": 5200,
        "percentage": 23.5
      },
      {
        "type": "investment",
        "name": "投資詐騙",
        "count": 4800,
        "percentage": 21.7
      },
      {
        "type": "lottery",
        "name": "假中獎通知",
        "count": 4200,
        "percentage": 19.0
      }
    ],
    "preventedLosses": {
      "estimatedAmount": 15000000,
      "currency": "TWD"
    }
  }
}
```

---

### 4.2 詐騙趨勢分析

**端點**: `GET /stats/trends`

**描述**: 獲取詐騙趨勢數據

**Query Parameters**:
```
?period=7d          // 7d, 30d, 90d, 1y
&category=all       // all, government_impersonation, lottery, investment
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "period": "7d",
    "dataPoints": [
      {
        "date": "2024-10-29",
        "total": 2500,
        "high": 1200,
        "medium": 800,
        "safe": 500
      },
      {
        "date": "2024-10-30",
        "total": 2650,
        "high": 1300,
        "medium": 850,
        "safe": 500
      }
      // ... 更多數據點
    ],
    "insights": [
      {
        "type": "trend",
        "severity": "warning",
        "message": "假冒公務機關詐騙案例較上週增加 15%"
      },
      {
        "type": "alert",
        "severity": "info",
        "message": "投資詐騙在週末時段較為活躍"
      }
    ]
  }
}
```

---

## 5. 關鍵字管理 API（管理員）

### 5.1 獲取關鍵字列表

**端點**: `GET /keywords`

**描述**: 獲取風險關鍵字配置

**Query Parameters**:
```
?severity=high      // high, medium, low
&category=all
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "keywords": [
      {
        "id": "kw_001",
        "text": "地檢署",
        "severity": "high",
        "weight": 30,
        "category": "government_impersonation",
        "language": "zh-TW",
        "active": true,
        "createdAt": "2024-01-15T00:00:00Z",
        "updatedAt": "2024-01-15T00:00:00Z"
      },
      {
        "id": "kw_002",
        "text": "中獎",
        "severity": "high",
        "weight": 30,
        "category": "lottery",
        "language": "zh-TW",
        "active": true,
        "createdAt": "2024-01-15T00:00:00Z",
        "updatedAt": "2024-01-15T00:00:00Z"
      }
    ],
    "totalKeywords": 150
  }
}
```

---

### 5.2 新增關鍵字

**端點**: `POST /keywords`

**描述**: 新增風險關鍵字（需要管理員權限）

**Request Body**:
```json
{
  "text": "NFT投資",
  "severity": "medium",
  "weight": 15,
  "category": "investment",
  "language": "zh-TW"
}
```

**成功響應** (201 Created):
```json
{
  "success": true,
  "data": {
    "id": "kw_new_123",
    "text": "NFT投資",
    "severity": "medium",
    "weight": 15,
    "category": "investment",
    "language": "zh-TW",
    "active": true,
    "createdAt": "2024-11-04T10:30:00Z"
  }
}
```

---

### 5.3 更新關鍵字

**端點**: `PATCH /keywords/:id`

**描述**: 更新關鍵字配置

**Request Body**:
```json
{
  "weight": 25,
  "active": true
}
```

---

### 5.4 刪除關鍵字

**端點**: `DELETE /keywords/:id`

**描述**: 刪除關鍵字（軟刪除）

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "message": "關鍵字已停用"
  }
}
```

---

## 6. 用戶管理 API（未來擴充）

### 6.1 用戶註冊

**端點**: `POST /users/register`

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "secure_password",
  "name": "王小明",
  "phoneNumber": "+886912345678"
}
```

---

### 6.2 用戶登入

**端點**: `POST /users/login`

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "secure_password"
}
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600,
    "user": {
      "id": "user_123",
      "email": "user@example.com",
      "name": "王小明",
      "role": "user"
    }
  }
}
```

---

### 6.3 獲取用戶資料

**端點**: `GET /users/me`

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": {
    "id": "user_123",
    "email": "user@example.com",
    "name": "王小明",
    "phoneNumber": "+886912345678",
    "role": "user",
    "stats": {
      "totalAnalyses": 45,
      "feedbacksSubmitted": 12,
      "accountCreatedAt": "2024-10-01T00:00:00Z"
    }
  }
}
```

---

### 6.4 分析歷史記錄

**端點**: `GET /users/me/history`

**Query Parameters**:
```
?page=1
&pageSize=20
&riskLevel=all      // all, high, medium, safe
&startDate=2024-10-01
&endDate=2024-11-04
```

**成功響應** (200 OK):
```json
{
  "success": true,
  "data": [
    {
      "analysisId": "ana_xyz123",
      "text": "您好，這裡是...",
      "textPreview": "您好，這裡是台北地檢署...",
      "riskLevel": "high",
      "riskScore": 85,
      "analyzedAt": "2024-11-03T15:30:00Z",
      "feedbackGiven": true
    },
    {
      "analysisId": "ana_xyz124",
      "text": "恭喜您中獎...",
      "textPreview": "恭喜您中獎了！...",
      "riskLevel": "high",
      "riskScore": 75,
      "analyzedAt": "2024-11-02T10:15:00Z",
      "feedbackGiven": false
    }
  ],
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "total": 45,
    "totalPages": 3
  }
}
```

---

## 7. Webhook 通知（未來擴充）

### 7.1 註冊 Webhook

**端點**: `POST /webhooks`

**描述**: 註冊接收高風險詐騙警報的 Webhook

**Request Body**:
```json
{
  "url": "https://your-domain.com/webhook/scam-alert",
  "events": ["high_risk_detected", "new_scam_pattern"],
  "secret": "your_webhook_secret"
}
```

---

### 7.2 Webhook Payload 範例

**Event**: `high_risk_detected`

```json
{
  "event": "high_risk_detected",
  "timestamp": "2024-11-04T10:30:00Z",
  "data": {
    "analysisId": "ana_urgent_123",
    "riskScore": 95,
    "category": "government_impersonation",
    "affectedUsers": 15,
    "urgency": "high"
  },
  "signature": "sha256_signature_here"
}
```

---

## 數據模型

### Analysis（分析記錄）
```typescript
interface Analysis {
  id: string;                    // 分析 ID
  text: string;                  // 輸入文字
  riskLevel: 'safe' | 'medium' | 'high';
  riskScore: number;             // 0-100
  confidence: number;            // 0-1
  reasons: Reason[];
  recommendation: Recommendation;
  detectedPatterns: DetectedPatterns;
  similarCases: SimilarCase[];
  metadata: {
    source?: 'sms' | 'phone' | 'email' | 'other';
    userAgent?: string;
    ipAddress?: string;
    sessionId?: string;
  };
  userId?: string;               // 可選，已登入用戶
  createdAt: string;             // ISO 8601
  updatedAt: string;
}
```

### Reason（風險原因）
```typescript
interface Reason {
  type: 'keyword' | 'pattern' | 'contact' | 'link' | 'urgency';
  severity: 'low' | 'medium' | 'high';
  description: string;
  weight: number;                // 影響權重
  matchedText?: string;          // 匹配的文字片段
}
```

### Recommendation（建議）
```typescript
interface Recommendation {
  text: string;
  actions: Action[];
}

interface Action {
  type: 'call' | 'link' | 'report' | 'ignore';
  label: string;
  value: string;                 // URL or tel: link
  priority: number;              // 1 = highest
}
```

### DetectedPatterns（偵測模式）
```typescript
interface DetectedPatterns {
  impersonation?: string[];      // ['government_agency', 'bank']
  urgency?: string[];            // ['immediate_action', 'time_limited']
  threats?: string[];            // ['account_freeze', 'legal_action']
  requestedInfo?: string[];      // ['phone_call', 'bank_account', 'password']
  suspiciousLinks?: string[];    // 可疑連結列表
}
```

### Feedback（回饋）
```typescript
interface Feedback {
  id: string;
  analysisId: string;
  isAccurate: boolean;
  feedbackType: 'accurate' | 'inaccurate' | 'false_positive' | 'false_negative';
  comment?: string;
  additionalInfo?: {
    actualOutcome?: 'confirmed_scam' | 'legitimate' | 'unknown';
    reportedToPolice?: boolean;
    financialLoss?: number;
  };
  userId?: string;
  sessionId?: string;
  createdAt: string;
}
```

### Keyword（關鍵字）
```typescript
interface Keyword {
  id: string;
  text: string;
  severity: 'low' | 'medium' | 'high';
  weight: number;                // 風險權重
  category: string;              // 'government_impersonation', 'lottery', 'investment'
  language: string;              // 'zh-TW', 'zh-CN', 'en'
  active: boolean;
  aliases?: string[];            // 同義詞
  regex?: string;                // 正則表達式匹配
  createdAt: string;
  updatedAt: string;
  createdBy?: string;            // 管理員 ID
}
```

### ScamCase（詐騙案例）
```typescript
interface ScamCase {
  id: string;
  text: string;
  category: string;
  riskLevel: 'safe' | 'medium' | 'high';
  tags: string[];
  verificationStatus: 'reported' | 'investigating' | 'confirmed_scam' | 'false_alarm';
  reportedDate: string;
  victimCount: number;
  estimatedLoss?: number;
  relatedCases?: string[];       // 相關案例 ID
  educationalNotes?: string;
  createdAt: string;
  updatedAt: string;
}
```

### User（用戶）
```typescript
interface User {
  id: string;
  email: string;
  passwordHash: string;          // bcrypt hashed
  name: string;
  phoneNumber?: string;
  role: 'user' | 'admin' | 'moderator';
  emailVerified: boolean;
  phoneVerified: boolean;
  preferences?: {
    language: string;
    notifications: boolean;
  };
  stats?: {
    totalAnalyses: number;
    feedbacksSubmitted: number;
    points: number;
  };
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}
```

---

## 錯誤代碼

### 客戶端錯誤 (4xx)

| 代碼 | HTTP 狀態 | 說明 |
|------|----------|------|
| `INVALID_INPUT` | 400 | 輸入數據格式錯誤或缺少必要欄位 |
| `TEXT_TOO_SHORT` | 400 | 輸入文字過短（少於 10 字符） |
| `TEXT_TOO_LONG` | 400 | 輸入文字過長（超過 5000 字符） |
| `UNAUTHORIZED` | 401 | 未提供或無效的認證憑證 |
| `FORBIDDEN` | 403 | 沒有權限訪問該資源 |
| `NOT_FOUND` | 404 | 請求的資源不存在 |
| `RATE_LIMIT_EXCEEDED` | 429 | 超過 API 請求頻率限制 |

### 伺服器錯誤 (5xx)

| 代碼 | HTTP 狀態 | 說明 |
|------|----------|------|
| `INTERNAL_ERROR` | 500 | 伺服器內部錯誤 |
| `AI_SERVICE_UNAVAILABLE` | 503 | AI 分析服務暫時不可用 |
| `DATABASE_ERROR` | 500 | 資料庫連接或查詢錯誤 |
| `TIMEOUT` | 504 | 請求處理超時 |

### 業務邏輯錯誤

| 代碼 | HTTP 狀態 | 說明 |
|------|----------|------|
| `ANALYSIS_FAILED` | 422 | 分析過程失敗 |
| `DUPLICATE_FEEDBACK` | 409 | 該分析已提交過回饋 |
| `INVALID_ANALYSIS_ID` | 400 | 無效的分析 ID |
| `KEYWORD_ALREADY_EXISTS` | 409 | 關鍵字已存在 |

---

## 性能要求

### 響應時間 SLA

| 端點 | 目標響應時間 | 最大響應時間 |
|------|-------------|-------------|
| `POST /analyze` | < 500ms | 2000ms |
| `POST /feedback` | < 200ms | 500ms |
| `GET /examples` | < 100ms | 300ms |
| `GET /stats/*` | < 300ms | 1000ms |

### 可用性要求
- **正常運行時間**: 99.5% (每月)
- **計劃維護**: 每月最多 4 小時
- **災難恢復**: RTO < 4 小時, RPO < 1 小時

### 並發處理能力
- **目標**: 1000 concurrent requests
- **尖峰處理**: 2000 concurrent requests
- **分析吞吐量**: 500 analyses/second

---

## 部署建議

### 技術棧建議

**後端框架**:
- Node.js + Express / Fastify
- Python + FastAPI
- Go + Gin

**資料庫**:
- 主資料庫: PostgreSQL (結構化數據)
- 快取: Redis (session, rate limiting)
- 搜尋引擎: Elasticsearch (案例搜尋)

**AI/ML 服務**:
- TensorFlow Serving
- PyTorch Serve
- Hugging Face Transformers

**部署平台**:
- Supabase (全棧解決方案)
- AWS (EC2, RDS, Lambda)
- Google Cloud Platform
- Azure

### 架構建議

```
                                    ┌─────────────┐
                                    │   CDN       │
                                    └──────┬──────┘
                                           │
                    ┌──────────────────────┴──────────────────────┐
                    │         Load Balancer (Nginx)               │
                    └──────────────────────┬──────────────────────┘
                                           │
                ┌──────────────────────────┼──────────────────────────┐
                │                          │                          │
         ┌──────┴──────┐          ┌───────┴────────┐        ┌────────┴────────┐
         │  API Server │          │  API Server    │        │  API Server     │
         │  Instance 1 │          │  Instance 2    │        │  Instance 3     │
         └──────┬──────┘          └───────┬────────┘        └────────┬────────┘
                │                          │                          │
                └──────────────────────────┼──────────────────────────┘
                                           │
                              ┌────────────┴────────────┐
                              │                         │
                    ┌─────────┴─────────┐    ┌─────────┴──────────┐
                    │   PostgreSQL      │    │   Redis Cache      │
                    │   (Primary/Replica)│    │   (Cluster)        │
                    └───────────────────┘    └────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │  AI Service       │
                    │  (Model Serving)  │
                    └───────────────────┘
```

### 環境變數配置

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/scam_detector
REDIS_URL=redis://localhost:6379

# API Configuration
API_VERSION=v1
API_PORT=3000
NODE_ENV=production

# AI Service
AI_SERVICE_URL=http://ai-service:8501
AI_MODEL_VERSION=1.0.0

# Authentication
JWT_SECRET=your-secret-key
JWT_EXPIRATION=3600
API_KEY_SALT=your-api-key-salt

# Rate Limiting
RATE_LIMIT_WINDOW=3600
RATE_LIMIT_MAX_REQUESTS=100

# External Services
SENTRY_DSN=https://xxx@sentry.io/xxx
LOG_LEVEL=info

# CORS
ALLOWED_ORIGINS=https://scam-detector.hsinchu.gov.tw
```

### 監控建議

**必要監控指標**:
- API 響應時間 (p50, p95, p99)
- 錯誤率
- 請求量 (QPS)
- AI 模型準確率
- 資料庫連接池使用率
- Redis 快取命中率

**推薦工具**:
- Application Performance: New Relic, Datadog
- Logging: ELK Stack, Grafana Loki
- Error Tracking: Sentry
- Uptime Monitoring: Pingdom, UptimeRobot

---

## 版本控制與變更記錄

### API 版本策略
- 使用 URL 路徑版本控制 (`/v1/`, `/v2/`)
- 保持向後兼容性至少 6 個月
- 廢棄通知至少提前 3 個月

### 變更記錄

**v1.0.0** (2024-11-04)
- 初始版本發布
- 核心分析 API
- 回饋系統
- 案例庫管理

---

## 附錄

### A. 測試用 API Key
```
開發環境: dev_test_key_12345abcde
測試環境: staging_test_key_67890fghij
```

### B. Postman Collection
提供完整的 Postman Collection 供測試使用:
- 匯入 URL: `https://api.hsinchu-scam-detector.tw/postman/collection.json`

### C. 支援與聯繫
- 技術支援: api-support@hsinchu.gov.tw
- 文件問題: docs@hsinchu.gov.tw
- 緊急聯繫: +886-3-1234-5678

---

**文件版本**: v1.0.0  
**最後更新**: 2024-11-04  
**維護團隊**: 新竹市政府數位發展處
