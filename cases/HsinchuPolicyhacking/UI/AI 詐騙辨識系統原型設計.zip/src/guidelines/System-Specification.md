# AI 詐騙辨識與預警系統 - 完整規格文件

## 1. 系統概述

### 1.1 專案資訊
- **專案名稱**: AI 詐騙辨識與預警系統
- **目標用戶**: 新竹市市民（特別關注長者、學生族群）
- **核心目標**: 降低詐騙案件發生率，提升市民詐騙辨識能力
- **系統類型**: 響應式 Web 應用程式（Progressive Web App）

### 1.2 核心價值主張
- 即時分析可疑訊息內容
- 提供三級風險評估（安全/中度/高度）
- 給予明確的行動建議
- 收集用戶回饋持續優化

---

## 2. 功能規格

### 2.1 核心功能模組

#### 2.1.1 文字輸入模組
**功能描述**: 接收用戶輸入的可疑訊息內容

**技術實作**:
- 元件: `<Textarea>` (Shadcn UI)
- 路徑: `/components/ScamAnalyzer.tsx`
- 最小高度: 150px
- 支援功能:
  - 直接輸入文字
  - 貼上文字內容
  - 自動調整高度（resize-none）
  - 分析中禁用輸入

**UI 規格**:
```tsx
<Textarea
  id="scam-input"
  placeholder="例如：「恭喜您中獎了！請點擊以下連結領取獎金...」或「這裡是台北地檢署，您涉及洗錢案件...」"
  className="min-h-[150px] text-base resize-none"
/>
```

**提示文字範例**:
- "例如：「恭喜您中獎了！請點擊以下連結領取獎金...」"
- "或「這裡是台北地檢署，您涉及洗錢案件...」"

---

#### 2.1.2 AI 分析引擎
**功能描述**: 分析輸入內容並評估詐騙風險

**實作位置**: `/components/ScamAnalyzer.tsx` - `performMockAnalysis()` 函數

**分析邏輯**:

##### 高風險關鍵字（每個 +30 分）:
- 假冒機關: 地檢署、警察局、健保局
- 金融詐騙: 中獎、獲利、投資、匯款、轉帳
- 帳戶安全: 帳戶異常、凍結、洗錢、密碼、驗證碼、解除分期

##### 中度風險關鍵字（每個 +10 分）:
- 壓力詞彙: 限時、立即、緊急
- 互動要求: 點擊連結、私訊、加入群組
- 平台: line、優惠

##### 風險加權規則:
- 可疑連結（http/bit.ly/連結）: +15 分
- 電話號碼模式: +10 分
- 緊急壓力詞彙: 額外標註原因

**風險評分計算**:
```javascript
riskScore = min(各項加總, 100)
```

**風險等級分類**:
- **高度風險**: riskScore ≥ 50
- **中度風險**: 20 ≤ riskScore < 50
- **安全**: riskScore < 20

---

#### 2.1.3 風險結果展示模組
**元件路徑**: `/components/RiskResult.tsx`

**視覺配置規範**:

##### 高度風險 (High)
```
顏色系統:
- 主色: Red (#DC2626)
- 背景: bg-red-50
- 邊框: border-red-300 (2px)
- 文字: text-red-900
- 徽章: bg-red-600

圖示: AlertCircle (lucide-react)
標籤: "高度風險"
描述: "極可能是詐騙訊息"
```

##### 中度風險 (Medium)
```
顏色系統:
- 主色: Yellow (#EAB308)
- 背景: bg-yellow-50
- 邊框: border-yellow-300 (2px)
- 文字: text-yellow-900
- 徽章: bg-yellow-500

圖示: AlertTriangle (lucide-react)
標籤: "中度風險"
描述: "請謹慎處理"
```

##### 安全 (Safe)
```
顏色系統:
- 主色: Green (#16A34A)
- 背景: bg-green-50
- 邊框: border-green-300 (2px)
- 文字: text-green-900
- 徽章: bg-green-600

圖示: Shield (lucide-react)
標籤: "安全"
描述: "未發現明顯威脅"
```

**結果卡片結構**:
1. **風險等級徽章**
   - 圖示（圓形背景，padding: 12px）
   - 等級名稱（h2 標題）
   - 風險描述（小字）
   - 風險評分（大字，右對齊）

2. **進度條**
   - 背景: 白色
   - 高度: 12px (h-3)
   - 圓角: rounded-full
   - 動畫: 1000ms ease-out
   - 寬度: 依評分百分比

3. **分析詳情卡片**
   - 標題: "分析結果"
   - 列表形式展示原因
   - 藍色圓點標記

4. **建議行動區**
   - Alert 元件
   - 建議文字
   - 行動按鈕（僅高風險顯示）

---

#### 2.1.4 建議與行動按鈕

**高度風險行動按鈕**:
```tsx
actionButtons: [
  { 
    text: '撥打 165 反詐騙專線', 
    link: 'tel:165' 
  },
  { 
    text: '前往刑事局網站查證', 
    link: 'https://www.165.gov.tw/' 
  }
]
```

**按鈕樣式**:
- 主按鈕: 紅色背景 (bg-red-600)
- 次按鈕: outline 樣式
- 圖示: Phone、ExternalLink

**建議文字模板**:

**高度風險**:
> "此訊息具有高度詐騙風險！請勿點擊任何連結、撥打電話或提供個人資料。建議立即向 165 反詐騙專線查證。"

**中度風險**:
> "此訊息存在中度風險，請謹慎處理。建議先向相關機構官方管道查證，切勿直接回應或提供個人資料。"

**安全**:
> "初步分析未發現明顯詐騙特徵，但仍請保持警覺。如有疑慮，建議向官方管道確認。"

---

#### 2.1.5 防詐小提醒區塊

**顯示條件**: 風險等級為中度或高度時顯示

**視覺規格**:
- 背景: bg-blue-50
- 邊框: border-blue-200
- 標題: text-blue-900
- 內容: text-blue-800

**固定提醒內容**:
- ✓ 政府機關不會以電話、簡訊要求您匯款或提供帳戶資料
- ✓ 接到可疑電話，請掛斷後自行查詢官方電話回撥確認
- ✓ 不明連結不要點、不明檔案不要下載
- ✓ 有疑慮請撥打 165 反詐騙諮詢專線

---

#### 2.1.6 使用者回饋模組
**元件路徑**: `/components/FeedbackSection.tsx`

**顯示條件**: 分析結果出現後自動顯示

**互動流程**:
1. 初始狀態: 顯示問題和兩個按鈕
2. 用戶點擊"準確"或"不準確"
3. 狀態變更為已提交
4. 顯示感謝訊息

**UI 規格**:

**初始狀態**:
```tsx
<Card className="bg-gray-50">
  問題: "此分析結果準確嗎？"
  說明: "您的回饋能幫助我們持續優化系統..."
  
  按鈕:
  - [👍 準確] hover:bg-green-50
  - [👎 不準確] hover:bg-red-50
</Card>
```

**已提交狀態**:
```tsx
<Card className="bg-green-50 border-green-200">
  圖示: CheckCircle2 (綠色)
  標題: "感謝您的回饋！"
  說明: "您的意見將幫助我們改進 AI 辨識系統..."
</Card>
```

---

#### 2.1.7 常見詐騙範例區

**顯示條件**: 尚未進行分析時顯示

**範例內容**:

**範例 1 - 假冒公務機關**:
> "您好，這裡是台北地檢署，您的帳戶涉及洗錢案件，請立即撥打 02-1234-5678 配合調查，否則將凍結您的所有帳戶。"

**範例 2 - 假中獎通知**:
> "恭喜您！您已被選中獲得 iPhone 15 Pro Max 一台，請點擊此連結 https://bit.ly/xxxxx 填寫資料領取，限時 24 小時。"

**範例 3 - 投資詐騙**:
> "獨家投資機會！加入 LINE 群組 @investpro，每月穩定獲利 30%，已有 5000 人加入，名額有限！立即私訊了解詳情。"

**互動行為**: 點擊範例自動填入輸入框

---

### 2.2 操作按鈕

#### 開始分析按鈕
```tsx
規格:
- 文字: "開始分析"
- 圖示: Send (lucide-react)
- 樣式: bg-blue-600 hover:bg-blue-700
- 禁用條件: 輸入為空或分析中
- 分析中顯示: "分析中..." + 旋轉動畫

尺寸: flex-1 (佔滿剩餘空間)
```

#### 清除按鈕
```tsx
規格:
- 文字: "清除"
- 圖示: X (lucide-react)
- 樣式: variant="outline"
- 禁用條件: 分析中
- 功能: 清空輸入、隱藏結果、隱藏回饋區
```

---

## 3. 頁面佈局規格

### 3.1 Header 區域

**元件結構**:
```tsx
<header className="bg-white shadow-sm">
  <div className="max-w-4xl mx-auto px-4 py-6">
    [Logo區] + [標題區]
  </div>
</header>
```

**Logo 規格**:
- 背景: bg-blue-600
- 圖示: Shield (white, 32px)
- 圓角: rounded-lg
- Padding: p-2

**標題規格**:
- 主標題: "AI 詐騙辨識與預警系統" (text-blue-900)
- 副標題: "保護您免受詐騙威脅，即時辨識可疑訊息" (text-gray-600, text-sm)

---

### 3.2 Main Content 區域

**容器規格**:
```tsx
<main className="max-w-4xl mx-auto px-4 py-8">
```

**最大寬度**: 896px (max-w-4xl)
**內距**: 水平 16px，垂直 32px

---

### 3.3 使用說明區

**顯示位置**: 分析器下方

**三步驟卡片**:
1. "複製可疑的簡訊或電話內容"
2. "貼上內容並點擊分析按鈕"
3. "查看風險評估並採取行動"

**視覺規格**:
- 數字徽章: bg-blue-100, 圓形, 48px
- 響應式: 單欄（手機）/ 三欄（桌面）
- Grid: `grid md:grid-cols-3 gap-4`

---

### 3.4 Footer 區域

**內容**:
```
新竹市政府 · 提升市民防詐意識
您的資料僅用於詐騙辨識，不會被儲存或分享
```

**樣式**:
- 對齊: text-center
- 顏色: text-gray-600
- 字體: text-sm
- 位置: mt-8

---

## 4. 技術架構規格

### 4.1 技術棧

**前端框架**:
- React 18+
- TypeScript

**UI 組件庫**:
- Shadcn UI (Tailwind CSS based)
- Lucide React (圖示)

**樣式方案**:
- Tailwind CSS v4.0
- 自定義 CSS (globals.css)

**狀態管理**:
- React Hooks (useState)
- 本地元件狀態

---

### 4.2 檔案結構

```
/
├── App.tsx                          # 主應用入口
├── components/
│   ├── ScamAnalyzer.tsx            # 分析器主元件
│   ├── RiskResult.tsx              # 風險結果展示
│   ├── FeedbackSection.tsx         # 回饋區塊
│   └── ui/                         # Shadcn UI 元件
│       ├── button.tsx
│       ├── textarea.tsx
│       ├── card.tsx
│       ├── alert.tsx
│       └── ...
├── styles/
│   └── globals.css                 # 全域樣式
└── guidelines/
    └── System-Specification.md     # 本規格文件
```

---

### 4.3 數據結構

#### AnalysisResult 介面
```typescript
interface AnalysisResult {
  riskLevel: 'safe' | 'medium' | 'high';  // 風險等級
  riskScore: number;                       // 風險分數 (0-100)
  reasons: string[];                       // 風險原因列表
  recommendation: string;                  // 建議文字
  actionButtons?: {                        // 行動按鈕（可選）
    text: string;
    link: string;
  }[];
}
```

#### 範例數據
```typescript
// 高風險範例
{
  riskLevel: 'high',
  riskScore: 75,
  reasons: [
    '包含高風險關鍵字：「地檢署」',
    '包含高風險關鍵字：「洗錢」',
    '使用緊急或限時詞彙，製造壓力',
    '要求撥打未經證實的電話號碼'
  ],
  recommendation: '此訊息具有高度詐騙風險！請勿點擊任何連結...',
  actionButtons: [
    { text: '撥打 165 反詐騙專線', link: 'tel:165' },
    { text: '前往刑事局網站查證', link: 'https://www.165.gov.tw/' }
  ]
}
```

---

### 4.4 狀態管理規格

**ScamAnalyzer 元件狀態**:
```typescript
const [inputText, setInputText] = useState<string>('');
const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
const [result, setResult] = useState<AnalysisResult | null>(null);
const [showFeedback, setShowFeedback] = useState<boolean>(false);
```

**FeedbackSection 元件狀態**:
```typescript
const [submitted, setSubmitted] = useState<boolean>(false);
const [feedbackType, setFeedbackType] = useState<'accurate' | 'inaccurate' | null>(null);
```

---

## 5. 互動流程規格

### 5.1 完整用戶流程

```
1. 頁面載入
   └─> 顯示空白輸入框 + 常見範例

2. 用戶輸入/選擇範例
   ├─> 手動輸入文字
   └─> 點擊範例自動填入

3. 點擊"開始分析"
   ├─> 按鈕變為禁用狀態
   ├─> 顯示"分析中..."和旋轉圖示
   └─> 1.5 秒模擬分析

4. 顯示分析結果
   ├─> 風險等級卡片（動畫進入）
   ├─> 進度條動畫（1 秒）
   ├─> 分析詳情
   ├─> 建議行動
   ├─> 防詐提醒（中/高風險）
   └─> 回饋區塊

5. 用戶互動
   ├─> 點擊行動按鈕（撥打165/開啟網站）
   ├─> 提交回饋（準確/不準確）
   └─> 點擊"清除"重新開始
```

---

### 5.2 動畫規格

**結果卡片進入動畫**:
```css
animate-in fade-in slide-in-from-bottom-4 duration-500
```

**進度條填充動畫**:
```css
transition-all duration-1000 ease-out
```

**按鈕載入動畫**:
```tsx
<Loader2 className="animate-spin" />
```

---

## 6. 響應式設計規格

### 6.1 斷點配置

**Tailwind 預設斷點**:
- `sm`: 640px
- `md`: 768px
- `lg`: 1024px
- `xl`: 1280px

### 6.2 響應式調整

**使用說明區**:
```tsx
// 手機: 單欄
// 平板以上: 三欄
grid md:grid-cols-3 gap-4
```

**行動按鈕**:
```tsx
// 手機: 垂直排列
// 平板以上: 水平排列
flex flex-col sm:flex-row gap-3
```

**容器內距**:
```tsx
// 所有裝置統一
px-4 py-8
```

---

## 7. 配色規範

### 7.1 主題色彩

**品牌色**:
- 主藍色: `#2563EB` (Blue-600)
- 深藍: `#1E3A8A` (Blue-900)

**風險色彩**:
- 高風險紅: `#DC2626` (Red-600)
- 中度黃: `#EAB308` (Yellow-500)
- 安全綠: `#16A34A` (Green-600)

**中性色**:
- 灰階: Gray-50 ~ Gray-900
- 白色: #FFFFFF
- 背景漸層: `from-blue-50 to-blue-100`

---

### 7.2 語意化配色

**信任與科技**:
- Header: 白色背景 + 藍色 Logo
- 按鈕: 藍色系

**警示系統**:
- 高風險: 紅色系（立即警覺）
- 中度: 黃色系（注意謹慎）
- 安全: 綠色系（放心）

**輔助資訊**:
- 提示: 藍色系（中性、專業）
- 成功: 綠色系（正向回饋）

---

## 8. 無障礙設計規格

### 8.1 語意化 HTML

- 使用 `<header>`, `<main>`, `<label>` 等語意標籤
- 表單元素正確關聯: `htmlFor` 與 `id`
- 按鈕使用 `<button>` 或 `<Button>` 元件

### 8.2 鍵盤導航

- 所有互動元素可透過 Tab 鍵訪問
- Button 元件支援鍵盤操作
- 禁用狀態正確處理

### 8.3 顏色對比

**符合 WCAG AA 標準**:
- 文字與背景對比度 ≥ 4.5:1
- 大標題對比度 ≥ 3:1
- 風險等級使用顏色+圖示+文字三重標示

### 8.4 字體大小

**基礎尺寸**:
- 正文: 16px (text-base)
- 小字: 14px (text-sm)
- 標題: globals.css 定義

**可讀性**:
- 最小字體不小於 14px
- 行距適中
- 避免純灰色小字

---

## 9. 性能規格

### 9.1 載入優化

- 元件按需載入
- SVG 圖示輕量化 (Lucide React)
- 無外部圖片依賴

### 9.2 互動性能

**分析模擬時間**: 1.5 秒
```typescript
setTimeout(() => {
  // 分析邏輯
}, 1500);
```

**動畫效能**:
- 使用 CSS transition
- 避免 layout thrashing
- GPU 加速動畫

---

## 10. 安全與隱私規格

### 10.1 數據處理

**目前實作**:
- 純前端分析，不發送後端
- 無數據儲存
- 無 Cookie 使用

**隱私聲明**:
> "您的資料僅用於詐騙辨識，不會被儲存或分享"

### 10.2 外部連結安全

```tsx
<a 
  href={button.link} 
  target="_blank" 
  rel="noopener noreferrer"
>
```

**安全屬性**:
- `target="_blank"`: 新視窗開啟
- `rel="noopener noreferrer"`: 防止安全漏洞

---

## 11. 測試規格

### 11.1 測試案例

**功能測試**:
- [ ] 輸入文字能正常顯示
- [ ] 點擊範例能自動填入
- [ ] 分析按鈕在空輸入時禁用
- [ ] 分析過程顯示載入狀態
- [ ] 不同風險等級正確顯示對應顏色
- [ ] 高風險顯示行動按鈕
- [ ] 回饋提交後顯示感謝訊息
- [ ] 清除按鈕重置所有狀態

**分析邏輯測試**:
- [ ] 包含"地檢署"觸發高風險
- [ ] 包含"中獎"觸發高風險
- [ ] 包含"限時"提示緊急詞彙
- [ ] 包含連結增加風險分數
- [ ] 正常訊息顯示安全

### 11.2 瀏覽器相容性

**支援瀏覽器**:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

**行動裝置**:
- iOS Safari 14+
- Android Chrome 90+

---

## 12. 未來擴充規劃

### 12.1 後端整合
- Supabase 數據庫連接
- 真實 AI 模型 API
- 用戶回饋數據收��

### 12.2 功能增強
- 語音輸入支援
- 歷史查詢記錄
- 詐騙案例資料庫
- 多語言支援（客語、原住民語）

### 12.3 進階分析
- 圖片文字辨識 (OCR)
- 電話號碼資料庫比對
- 網址安全性檢測
- 即時詐騙趨勢報告

---

## 13. 版本資訊

**當前版本**: v1.0.0 (MVP)
**最後更新**: 2024-11-04
**維護單位**: 新竹市政府

---

## 附錄 A: 關鍵字清單

### 高風險關鍵字 (+30 分)
```
假冒機關: 地檢署、警察局、健保局
金融詐騙: 中獎、獲利、投資、匯款、轉帳
帳戶安全: 帳戶異常、凍結、洗錢、密碼、驗證碼、解除分期
```

### 中度風險關鍵字 (+10 分)
```
壓力詞彙: 限時、立即、緊急
互動要求: 點擊連結、私訊、加入群組
平台: line、優惠
```

---

## 附錄 B: 元件 Props 規格

### ScamAnalyzer
```typescript
// 無 Props (獨立元件)
export function ScamAnalyzer(): JSX.Element
```

### RiskResult
```typescript
interface RiskResultProps {
  result: AnalysisResult;
}
export function RiskResult({ result }: RiskResultProps): JSX.Element
```

### FeedbackSection
```typescript
interface FeedbackSectionProps {
  onFeedback: (isAccurate: boolean) => void;
}
export function FeedbackSection({ onFeedback }: FeedbackSectionProps): JSX.Element
```

---

## 附錄 C: CSS 類別速查

### 常用顏色類別
```css
/* 藍色系 */
.bg-blue-50, .bg-blue-100, .bg-blue-600, .text-blue-600, .text-blue-900

/* 紅色系 */
.bg-red-50, .bg-red-600, .text-red-900, .border-red-300

/* 黃色系 */
.bg-yellow-50, .bg-yellow-500, .text-yellow-900, .border-yellow-300

/* 綠色系 */
.bg-green-50, .bg-green-600, .text-green-900, .border-green-200

/* 灰色系 */
.bg-gray-50, .text-gray-600, .text-gray-700, .border-gray-200
```

### 常用佈局類別
```css
/* 容器 */
.max-w-4xl, .mx-auto, .px-4, .py-6, .py-8

/* Flexbox */
.flex, .items-center, .gap-3, .flex-1

/* Grid */
.grid, .md:grid-cols-3, .gap-4

/* 間距 */
.mt-1, .mt-2, .mt-3, .mt-4, .mt-8, .mb-3, .mb-4
```

---

**規格文件結束**

如有任何疑問或需要進一步說明，請聯繫開發團隊。
