import { useState } from 'react';
import { ScamAnalyzer } from './components/ScamAnalyzer';
import { Shield } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-blue-900">AI 詐騙辨識與預警系統</h1>
              <p className="text-gray-600 text-sm mt-1">保護您免受詐騙威脅，即時辨識可疑訊息</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <ScamAnalyzer />
        
        {/* Info Section */}
        <div className="mt-8 bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-blue-900 mb-4">如何使用</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-blue-600">1</span>
              </div>
              <p className="text-gray-700">複製可疑的簡訊或電話內容</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-blue-600">2</span>
              </div>
              <p className="text-gray-700">貼上內容並點擊分析按鈕</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-blue-600">3</span>
              </div>
              <p className="text-gray-700">查看風險評估並採取行動</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-gray-600 text-sm">
          <p>新竹市政府 · 提升市民防詐意識</p>
          <p className="mt-2">您的資料僅用於詐騙辨識，不會被儲存或分享</p>
        </div>
      </main>
    </div>
  );
}
