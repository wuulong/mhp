import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ThumbsUp, ThumbsDown, CheckCircle2 } from 'lucide-react';

interface FeedbackSectionProps {
  onFeedback: (isAccurate: boolean) => void;
}

export function FeedbackSection({ onFeedback }: FeedbackSectionProps) {
  const [submitted, setSubmitted] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'accurate' | 'inaccurate' | null>(null);

  const handleFeedback = (isAccurate: boolean) => {
    setFeedbackType(isAccurate ? 'accurate' : 'inaccurate');
    setSubmitted(true);
    onFeedback(isAccurate);
  };

  if (submitted) {
    return (
      <Card className="bg-green-50 border-green-200">
        <div className="p-6">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <h3 className="text-green-900">感謝您的回饋！</h3>
              <p className="text-green-700 text-sm mt-1">
                您的意見將幫助我們改進 AI 辨識系統，為更多市民提供更準確的防詐保護。
              </p>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-gray-50">
      <div className="p-6">
        <h3 className="text-gray-900 mb-3">此分析結果準確嗎？</h3>
        <p className="text-gray-600 text-sm mb-4">
          您的回饋能幫助我們持續優化系統，提供更精準的詐騙辨識服務。
        </p>
        <div className="flex gap-3">
          <Button
            onClick={() => handleFeedback(true)}
            variant="outline"
            className="flex-1 hover:bg-green-50 hover:border-green-300"
          >
            <ThumbsUp className="mr-2 h-5 w-5" />
            準確
          </Button>
          <Button
            onClick={() => handleFeedback(false)}
            variant="outline"
            className="flex-1 hover:bg-red-50 hover:border-red-300"
          >
            <ThumbsDown className="mr-2 h-5 w-5" />
            不準確
          </Button>
        </div>
      </div>
    </Card>
  );
}
