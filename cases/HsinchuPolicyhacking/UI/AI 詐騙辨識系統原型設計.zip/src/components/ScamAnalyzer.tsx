import { useState } from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Loader2, Send, X } from 'lucide-react';
import { RiskResult } from './RiskResult';
import { FeedbackSection } from './FeedbackSection';

export interface AnalysisResult {
  riskLevel: 'safe' | 'medium' | 'high';
  riskScore: number;
  reasons: string[];
  recommendation: string;
  actionButtons?: {
    text: string;
    link: string;
  }[];
}

export function ScamAnalyzer() {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const analyzeText = async () => {
    if (!inputText.trim()) {
      return;
    }

    setIsAnalyzing(true);
    setResult(null);
    setShowFeedback(false);

    // Simulate AI analysis with mock logic
    setTimeout(() => {
      const analysis = performMockAnalysis(inputText);
      setResult(analysis);
      setIsAnalyzing(false);
      setShowFeedback(true);
    }, 1500);
  };

  const handleClear = () => {
    setInputText('');
    setResult(null);
    setShowFeedback(false);
  };

  const handleFeedback = (isAccurate: boolean) => {
    console.log('User feedback:', isAccurate ? '準確' : '不準確');
    // In real implementation, this would send feedback to backend
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="mb-4">
          <label htmlFor="scam-input" className="block text-gray-700 mb-2">
            請輸入或貼上可疑的簡訊、電話內容
          </label>
          <Textarea
            id="scam-input"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="例如：「恭喜您中獎了！請點擊以下連結領取獎金...」或「這裡是台北地檢署，您涉及洗錢案件...」"
            className="min-h-[150px] text-base resize-none"
            disabled={isAnalyzing}
          />
        </div>

        <div className="flex gap-3">
          <Button
            onClick={analyzeText}
            disabled={!inputText.trim() || isAnalyzing}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                分析中...
              </>
            ) : (
              <>
                <Send className="mr-2 h-5 w-5" />
                開始分析
              </>
            )}
          </Button>
          <Button
            onClick={handleClear}
            variant="outline"
            disabled={isAnalyzing}
          >
            <X className="mr-2 h-5 w-5" />
            清除
          </Button>
        </div>
      </div>

      {/* Analysis Result */}
      {result && (
        <RiskResult result={result} />
      )}

      {/* Feedback Section */}
      {showFeedback && result && (
        <FeedbackSection onFeedback={handleFeedback} />
      )}

      {/* Example Messages */}
      {!result && (
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-gray-700 mb-3">常見詐騙訊息範例</h3>
          <div className="space-y-2">
            <button
              onClick={() => setInputText('您好，這裡是台北地檢署，您的帳戶涉及洗錢案件，請立即撥打 02-1234-5678 配合調查，否則將凍結您的所有帳戶。')}
              className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              假冒公務機關：「這裡是台北地檢署，您的帳戶涉及洗錢案件...」
            </button>
            <button
              onClick={() => setInputText('恭喜您！您已被選中獲得 iPhone 15 Pro Max 一台，請點擊此連結 https://bit.ly/xxxxx 填寫資料領取，限時 24 小時。')}
              className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              假中獎通知：「恭喜您！您已被選中獲得 iPhone 15 Pro Max...」
            </button>
            <button
              onClick={() => setInputText('獨家投資機會！加入 LINE 群組 @investpro，每月穩定獲利 30%，已有 5000 人加入，名額有限！立即私訊了解詳情。')}
              className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              投資詐騙：「獨家投資機會！每月穩定獲利 30%...」
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Mock AI analysis function
function performMockAnalysis(text: string): AnalysisResult {
  const lowerText = text.toLowerCase();
  
  // High risk keywords
  const highRiskKeywords = ['地檢署', '警察局', '健保局', '中獎', '獲利', '投資', '帳戶異常', '凍結', '洗錢', '匯款', '轉帳', '密碼', '驗證碼', '解除分期'];
  const mediumRiskKeywords = ['限時', '立即', '緊急', '點擊連結', '私訊', '加入群組', 'line', '優惠'];
  
  let riskScore = 0;
  const reasons: string[] = [];
  
  // Check for high risk keywords
  highRiskKeywords.forEach(keyword => {
    if (lowerText.includes(keyword)) {
      riskScore += 30;
      reasons.push(`包含高風險關鍵字：「${keyword}」`);
    }
  });
  
  // Check for medium risk keywords
  mediumRiskKeywords.forEach(keyword => {
    if (lowerText.includes(keyword)) {
      riskScore += 10;
    }
  });
  
  // Check for urgency
  if (lowerText.includes('立即') || lowerText.includes('馬上') || lowerText.includes('限時')) {
    reasons.push('使用緊急或限時詞彙，製造壓力');
  }
  
  // Check for suspicious links
  if (lowerText.includes('http') || lowerText.includes('bit.ly') || lowerText.includes('連結')) {
    riskScore += 15;
    reasons.push('包含可疑連結');
  }
  
  // Check for phone numbers
  if (/\d{2,4}-\d{4,8}/.test(text) || /\d{10,}/.test(text)) {
    riskScore += 10;
    reasons.push('要求撥打未經證實的電話號碼');
  }
  
  // Determine risk level
  let riskLevel: 'safe' | 'medium' | 'high';
  let recommendation: string;
  let actionButtons: { text: string; link: string; }[] = [];
  
  if (riskScore >= 50) {
    riskLevel = 'high';
    recommendation = '此訊息具有高度詐騙風險！請勿點擊任何連結、撥打電話或提供個人資料。建議立即向 165 反詐騙專線查證。';
    actionButtons = [
      { text: '撥打 165 反詐騙專線', link: 'tel:165' },
      { text: '前往刑事局網站查證', link: 'https://www.165.gov.tw/' }
    ];
    if (reasons.length === 0) {
      reasons.push('綜合分析顯示多項詐騙特徵');
    }
  } else if (riskScore >= 20) {
    riskLevel = 'medium';
    recommendation = '此訊息存在中度風險，請謹慎處理。建議先向相關機構官方管道查證，切勿直接回應或提供個人資料。';
    reasons.push('訊息內容需要進一步查證');
  } else {
    riskLevel = 'safe';
    recommendation = '初步分析未發現明顯詐騙特徵，但仍請保持警覺。如有疑慮，建議向官方管道確認。';
    if (reasons.length === 0) {
      reasons.push('未發現明顯詐騙關鍵字');
      reasons.push('訊息內容相對正常');
    }
  }
  
  return {
    riskLevel,
    riskScore: Math.min(riskScore, 100),
    reasons,
    recommendation,
    actionButtons: actionButtons.length > 0 ? actionButtons : undefined
  };
}
