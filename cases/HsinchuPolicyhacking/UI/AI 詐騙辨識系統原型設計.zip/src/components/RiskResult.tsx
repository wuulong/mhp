import { Shield, AlertTriangle, AlertCircle, Phone, ExternalLink } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import type { AnalysisResult } from './ScamAnalyzer';

interface RiskResultProps {
  result: AnalysisResult;
}

export function RiskResult({ result }: RiskResultProps) {
  const getRiskConfig = () => {
    switch (result.riskLevel) {
      case 'high':
        return {
          color: 'red',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-300',
          textColor: 'text-red-900',
          badgeBg: 'bg-red-600',
          icon: AlertCircle,
          label: '高度風險',
          description: '極可能是詐騙訊息'
        };
      case 'medium':
        return {
          color: 'yellow',
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-300',
          textColor: 'text-yellow-900',
          badgeBg: 'bg-yellow-500',
          icon: AlertTriangle,
          label: '中度風險',
          description: '請謹慎處理'
        };
      case 'safe':
        return {
          color: 'green',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-300',
          textColor: 'text-green-900',
          badgeBg: 'bg-green-600',
          icon: Shield,
          label: '安全',
          description: '未發現明顯威脅'
        };
    }
  };

  const config = getRiskConfig();
  const Icon = config.icon;

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Risk Level Badge */}
      <Card className={`${config.bgColor} ${config.borderColor} border-2`}>
        <div className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className={`${config.badgeBg} p-3 rounded-full`}>
              <Icon className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h2 className={config.textColor}>{config.label}</h2>
              <p className={`${config.textColor} text-sm mt-1`}>{config.description}</p>
            </div>
            <div className="text-right">
              <div className={`${config.textColor} text-sm`}>風險評分</div>
              <div className={`${config.textColor} text-3xl`}>
                {result.riskScore}
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-white rounded-full h-3 overflow-hidden">
            <div
              className={`h-full ${config.badgeBg} transition-all duration-1000 ease-out`}
              style={{ width: `${result.riskScore}%` }}
            />
          </div>
        </div>
      </Card>

      {/* Analysis Details */}
      <Card className="bg-white">
        <div className="p-6">
          <h3 className="text-gray-900 mb-3">分析結果</h3>
          <ul className="space-y-2">
            {result.reasons.map((reason, index) => (
              <li key={index} className="flex items-start gap-2 text-gray-700">
                <span className="text-blue-600 mt-1">•</span>
                <span>{reason}</span>
              </li>
            ))}
          </ul>
        </div>
      </Card>

      {/* Recommendation */}
      <Alert className={`${config.bgColor} ${config.borderColor} border-2`}>
        <AlertDescription className={config.textColor}>
          <div className="space-y-4">
            <p>{result.recommendation}</p>
            
            {/* Action Buttons */}
            {result.actionButtons && result.actionButtons.length > 0 && (
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                {result.actionButtons.map((button, index) => (
                  <Button
                    key={index}
                    asChild
                    variant={index === 0 ? 'default' : 'outline'}
                    className={index === 0 ? 'bg-red-600 hover:bg-red-700' : ''}
                  >
                    <a href={button.link} target="_blank" rel="noopener noreferrer">
                      {index === 0 ? (
                        <Phone className="mr-2 h-4 w-4" />
                      ) : (
                        <ExternalLink className="mr-2 h-4 w-4" />
                      )}
                      {button.text}
                    </a>
                  </Button>
                ))}
              </div>
            )}
          </div>
        </AlertDescription>
      </Alert>

      {/* General Safety Tips */}
      {result.riskLevel !== 'safe' && (
        <Card className="bg-blue-50 border-blue-200">
          <div className="p-6">
            <h3 className="text-blue-900 mb-3">防詐小提醒</h3>
            <ul className="space-y-2 text-blue-800 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-blue-600">✓</span>
                <span>政府機關不會以電話、簡訊要求您匯款或提供帳戶資料</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600">✓</span>
                <span>接到可疑電話，請掛斷後自行查詢官方電話回撥確認</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600">✓</span>
                <span>不明連結不要點、不明檔案不要下載</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600">✓</span>
                <span>有疑慮請撥打 165 反詐騙諮詢專線</span>
              </li>
            </ul>
          </div>
        </Card>
      )}
    </div>
  );
}
